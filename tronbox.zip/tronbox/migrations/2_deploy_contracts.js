var TBS = artifacts.require("./TBS.sol");

module.exports = function(deployer) {
  deployer.deploy(TBS);
};
